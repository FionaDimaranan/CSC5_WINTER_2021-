/* 
 * File:   main.cpp
 * Author: fiona dimaranan
 * Created on January 12, 2021, 11:52 AM
 * Purpose:  Gaddis_9thEd_Chap3_Prob7_Cookies
 */

//System Libraries
#include <iostream> //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    short numCook,cals;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
   
    //Display the outputs
    cout<<"Calorie Counter"<<endl;
    cout<<"How many cookies did you eat?"<<endl;
    
    cin>>numCook;
    
    cals=numCook*75;
    
    cout<<"You consumed "<<cals<<" calories.";
    //Exit stage right or left!
    return 0;
}