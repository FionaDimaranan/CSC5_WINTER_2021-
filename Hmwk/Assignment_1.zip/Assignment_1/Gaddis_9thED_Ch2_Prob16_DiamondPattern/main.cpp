/* 
 * File:   main.cpp
 * Author: fiona
 * Created on January 5, 2021, 6:49 PM
 * Purpose: Write a program that displays a Diamond Pattern
 */

//System Libraries
#include <iostream> //I/O/Library

using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal Constants, High Dimensional Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the random number seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //map inputs to outputs -> process
    
    //display inputs/outputs
    cout<<"    *\n"
        <<"   ***\n"
        <<"  *****\n"
        <<" *******\n"
        <<"  *****\n"
        <<"   ***\n"
        <<"    *\n";
    
    //exit program-cleanup
    return 0;
}

