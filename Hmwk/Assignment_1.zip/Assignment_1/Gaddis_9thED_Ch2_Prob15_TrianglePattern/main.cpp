/* 
 * File:   main.cpp
 * Author: fiona
 * Created on January 5 , 2021, 12:40 PM
 * Purpose: HW Assignment 1, Gaddis Ch2 Problem 15 "Triangle Pattern"
 */

//System Libraries
#include <iostream> //I/O/Library

using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal Constants, High Dimensional Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the random number seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //map inputs to outputs -> process
    
    //display inputs/outputs
    cout<<"     *\n";
    cout<<"    ***\n ";
    cout<<"  *****\n ";
    cout<<" *******\n ";
    
    //exit program-cleanup
    return 0;
}

