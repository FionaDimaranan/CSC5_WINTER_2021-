/* 
 * File:   main.cpp
 * Author: fiona
 * Created on January 5, 2021, 6:40 PM
 * Purpose: Write a program that displays the following information, each on a 
 separate line: your name, address, telephone number and major
 Use only a single cout to display this information. 
 * 
 */

//System Libraries
#include <iostream> //I/O/Library

using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal Constants, High Dimensional Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the random number seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //map inputs to outputs -> process
    
    //display inputs/outputs
    cout<<"Fiona Dimaranan\n"                           //my name
        <<"12192 Brianwood Dr, Riverside CA 92503\n"    //my address
        <<"(909)524-8001\n"                             //my phone number
        <<"Biology\n";                                  //my major
    
    //exit program-cleanup
    return 0;
}

